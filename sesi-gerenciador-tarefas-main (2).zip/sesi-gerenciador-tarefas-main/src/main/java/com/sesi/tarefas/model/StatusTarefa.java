package com.sesi.tarefas.model;

public enum StatusTarefa {
	A_FAZER, FAZENDO, PRONTO
}
