package com.sesi.tarefas.model;

public enum Prioridade {
	BAIXA, MEDIA, ALTA
}
