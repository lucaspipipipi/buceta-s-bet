package com.sesi.tarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
