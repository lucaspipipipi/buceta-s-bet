package com.example.Front_END_TCC.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Front_END_TCC.Model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long>{

}
