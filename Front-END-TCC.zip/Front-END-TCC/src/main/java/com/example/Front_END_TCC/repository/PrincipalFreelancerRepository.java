package com.example.Front_END_TCC.repository;

 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Front_END_TCC.Model.PrincipalFreelancer;

@Repository
public interface PrincipalFreelancerRepository extends JpaRepository<PrincipalFreelancer, Long> {
    // Você pode adicionar métodos personalizados se necessário
}
