package com.example.Front_END_TCC.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.Front_END_TCC.Model.PrincipalFreelancer;
import com.example.Front_END_TCC.repository.PrincipalFreelancerRepository;

import java.util.List;

@RestController
@RequestMapping("/api/freelancers")
public class PrincipalFreelancerController {

    @Autowired
    private PrincipalFreelancerRepository freelancerRepository;

    @GetMapping
    public List<PrincipalFreelancer> getAllFreelancers() {
        return freelancerRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PrincipalFreelancer> getFreelancerById(@PathVariable Long id) {
        return freelancerRepository.findById(id)
            .map(freelancer -> ResponseEntity.ok(freelancer))
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<PrincipalFreelancer> createFreelancer(@RequestBody PrincipalFreelancer freelancer) {
        PrincipalFreelancer savedFreelancer = freelancerRepository.save(freelancer);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedFreelancer);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PrincipalFreelancer> updateFreelancer(@PathVariable Long id, @RequestBody PrincipalFreelancer freelancerDetails) {
        return freelancerRepository.findById(id)
            .map(freelancer -> {
                freelancer.setNome(freelancerDetails.getNome());
                freelancer.setEmail(freelancerDetails.getEmail());
                freelancer.setDescricao(freelancerDetails.getDescricao());
                freelancer.setProjetosAtivos(freelancerDetails.getProjetosAtivos());
                PrincipalFreelancer updatedFreelancer = freelancerRepository.save(freelancer);
                return ResponseEntity.ok(updatedFreelancer);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteFreelancer(@PathVariable Long id) {
        return freelancerRepository.findById(id)
            .map(freelancer -> {
                freelancerRepository.delete(freelancer);
                return ResponseEntity.noContent().build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
}
