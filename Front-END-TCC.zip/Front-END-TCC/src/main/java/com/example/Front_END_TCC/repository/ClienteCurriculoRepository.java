package com.example.Front_END_TCC.repository;

import com.example.Front_END_TCC.Model.ClienteCurriculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteCurriculoRepository extends JpaRepository<ClienteCurriculo, Long> {
    // Métodos personalizados podem ser adicionados aqui
}
