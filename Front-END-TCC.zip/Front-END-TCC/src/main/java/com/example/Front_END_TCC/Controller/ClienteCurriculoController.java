package com.example.Front_END_TCC.Controller;

import com.example.Front_END_TCC.Model.ClienteCurriculo;
import com.example.Front_END_TCC.repository.ClienteCurriculoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/clientes-curriculo")
public class ClienteCurriculoController {

    @Autowired
    private ClienteCurriculoRepository clienteCurriculoRepository;

    @GetMapping("/{id}")
    public ResponseEntity<ClienteCurriculo> getCliente(@PathVariable Long id) {
        Optional<ClienteCurriculo> clienteCurriculo = clienteCurriculoRepository.findById(id);
        return clienteCurriculo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ClienteCurriculo> criarCliente(@RequestBody ClienteCurriculo clienteCurriculo) {
        try {
            ClienteCurriculo novoClienteCurriculo = clienteCurriculoRepository.save(clienteCurriculo);
            return new ResponseEntity<>(novoClienteCurriculo, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClienteCurriculo> atualizarCliente(@PathVariable Long id, @RequestBody ClienteCurriculo clienteAtualizado) {
        return clienteCurriculoRepository.findById(id).map(clienteCurriculo -> {
            clienteCurriculo.setNome(clienteAtualizado.getNome());
            clienteCurriculo.setEmail(clienteAtualizado.getEmail());
            clienteCurriculo.setTelefone(clienteAtualizado.getTelefone());
            clienteCurriculo.setExperiencia(clienteAtualizado.getExperiencia());
            clienteCurriculo.setFormacao(clienteAtualizado.getFormacao());
            clienteCurriculo.setHabilidades(clienteAtualizado.getHabilidades());
            ClienteCurriculo clienteSalvo = clienteCurriculoRepository.save(clienteCurriculo);
            return new ResponseEntity<>(clienteSalvo, HttpStatus.OK);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @GetMapping("/curriculo/{id}")
    public String getClienteCurriculo(@PathVariable Long id, Model model) {
        ClienteCurriculo clienteCurriculo = clienteCurriculoRepository.findById(id).orElse(null);
        model.addAttribute("clienteCurriculo", clienteCurriculo);
        return "clienteCurriculo";
    }

}
