package com.example.Front_END_TCC.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Front_END_TCC.Model.PrincipalCliente;

@Repository
public interface PrincipalClienteRepository extends JpaRepository<PrincipalCliente, Long> {
    // Você pode adicionar consultas personalizadas aqui, se necessário
}