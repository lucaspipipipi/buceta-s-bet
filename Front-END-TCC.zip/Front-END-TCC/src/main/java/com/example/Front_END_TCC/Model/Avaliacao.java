package com.example.Front_END_TCC.Model;

public class Avaliacao {

}
