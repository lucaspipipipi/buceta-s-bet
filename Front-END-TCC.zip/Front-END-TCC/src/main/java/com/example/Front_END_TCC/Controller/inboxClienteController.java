package com.example.Front_END_TCC.Controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Front_END_TCC.Model.PropostaClienteDTO;

@Controller
@RequestMapping("/InboxCliente")
public class inboxClienteController {

    @GetMapping
    public String listarPropostas(Model model) {
        // Simulação de propostas enviadas pelo cliente (dados fictícios)
        List<PropostaClienteDTO> propostas = List.of(
            new PropostaClienteDTO(1L, "Freelancer João", "Desenvolvimento de aplicativo mobile"),
            new PropostaClienteDTO(2L, "Freelancer Maria", "Consultoria em marketing digital"),
            new PropostaClienteDTO(3L, "Freelancer Carlos", "Criação de site para e-commerce")
        );

        model.addAttribute("propostas", propostas);
        return "InboxCliente";
    }
}
