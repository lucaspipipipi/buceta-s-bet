package com.example.Front_END_TCC.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Front_END_TCC.Model.Pagamento;
public interface PagamentoRepository extends JpaRepository<Pagamento, Long> {
    // Aqui você pode adicionar métodos específicos, se necessário
}
