package com.example.Front_END_TCC.Controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Front_END_TCC.Model.PropostaDTO;

@Controller
@RequestMapping("/inboxFreelancer")
public class InboxFreelancerController {

    @GetMapping
    public String listarPropostas(Model model) {
        // Simulação de propostas (dados fictícios)
        List<PropostaDTO> propostas = List.of(
            new PropostaDTO(1L, "João Silva", "Preciso de um site para minha empresa."),
            new PropostaDTO(2L, "Maria Oliveira", "Preciso de um aplicativo mobile."),
            new PropostaDTO(3L, "Carlos Souza", "Necessito de consultoria em TI.")
        );

        model.addAttribute("propostas", propostas);
        return "inboxFreelancer";
    }
}
