package com.example.Front_END_TCC.Model;

public class PropostaClienteDTO {
    private Long id;
    private String nomeFreelancer;
    private String descricao;

    // Construtor
    public PropostaClienteDTO(Long id, String nomeFreelancer, String descricao) {
        this.id = id;
        this.nomeFreelancer = nomeFreelancer;
        this.descricao = descricao;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeFreelancer() {
        return nomeFreelancer;
    }

    public void setNomeFreelancer(String nomeFreelancer) {
        this.nomeFreelancer = nomeFreelancer;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
