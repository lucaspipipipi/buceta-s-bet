package com.example.Front_END_TCC.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.Front_END_TCC.Model.Pagamento;
import com.example.Front_END_TCC.repository.PagamentoRepository;

@Controller
public class PagamentoController {

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @GetMapping("/cliente/pagamento/cadastrar")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("pagamento", new Pagamento());
        return "pagamento/cadastrar"; // Nome do template Thymeleaf
    }

    @PostMapping("/cliente/pagamento/salvar")
    public String salvarPagamento(Pagamento pagamento) {
        pagamentoRepository.save(pagamento);
        return "redirect:/cliente/pagamento/sucesso"; // Redireciona para uma página de sucesso
    }

    // Método para a página de sucesso (opcional)
    @GetMapping("/cliente/pagamento/sucesso")
    public String mostrarPaginaSucesso() {
        return "pagamento/sucesso"; // Nome do template de sucesso
    }
}
